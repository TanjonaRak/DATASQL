package client;
import java.io.*;
import java.net.*;
import java.util.*;
public class Client{
	public static void main(String[] args) {
		try{
			Socket soc=new Socket("localhost",123);
			Scanner sc=new Scanner(System.in);
			InputStream inp=soc.getInputStream();
			//InputStreamReader r=new InputStreamReader(inp);
			OutputStream oup=soc.getOutputStream();
			//OutputStreamWriter r=new OutputStreamWriter(oup);
			PrintWriter outlire=new PrintWriter(oup);
			String test=sc.nextLine();
			outlire.println(test);
			outlire.flush();
			//System.out.println("voter table creee");
			//OutputStreamWriter r=new OutputStreamWriter(inp);
		}catch(Exception e){e.printStackTrace();}
	}
}