package connect;
public class ConnectionDATA{
	
} 